# Charity
 a charity web app project , first project with django framework
